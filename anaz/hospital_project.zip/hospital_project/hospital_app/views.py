
from django.shortcuts import render,redirect
from . models import *

# Create your views here.
def home(request):
    return render(request,'home.html')
def reg(request):

    if request.method == 'POST':
        name=request.POST['u_name']
        dob=request.POST['u_dob']
        age=request.POST['u_age']
        address=request.POST['u_address']
        phone=request.POST['u_num']
        email=request.POST['u_mail']
    
        if Reg_Form.objects.filter(Email=email).exists():
            msg="alredy"
        else:
             Reg_Form.objects.create(Username=name,Date=dob,Age=age,Address=address,Contact=phone,Email=email)
       

        

    return redirect(home)
def u_list(request):
    data=Reg_Form.objects.all()
    return render(request,'reg_list.html',{'data':data})

def updateu(request):

    if request.method == 'POST':
        id=request.POST['u_id']
        name=request.POST['u_name']
        phone=request.POST['u_num']
        email=request.POST['u_mail']

        Reg_Form.objects.filter(id=id).update(Username=name,Contact=phone,Email=email)
        
        

    return redirect(u_list)

def dlt(request):
    if request.method == 'POST':
         id=request.POST['s_id']
         Reg_Form.objects.filter(id=id).delete()

    return redirect(u_list)

