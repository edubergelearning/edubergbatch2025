from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('reg',views.reg,name='reg'),
    path('list',views.u_list,name='ulist'),
    path('updateu',views.updateu,name='updateu'),
    path('dlt',views.dlt,name='dlt')
]