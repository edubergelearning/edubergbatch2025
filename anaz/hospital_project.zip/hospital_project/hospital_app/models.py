from django.db import models

# Create your models here.
class Reg_Form(models.Model):
    Username=models.CharField(max_length=100)
    Date=models.DateField()
    Age=models.CharField(max_length=2)
    Address=models.CharField(max_length=500)
    Contact=models.BigIntegerField()
    Email=models.EmailField()
