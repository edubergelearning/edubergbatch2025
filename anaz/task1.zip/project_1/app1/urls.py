from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name="home"),
    path('tst',views.tst,name="tst"),

    # path('sheri',views.sheri,name="sheriii"),
    # path('sum',views.sum,name="sheriii")

]
