from django.db import models

# Create your models here.
class Reg(models.Model):
    fi_num=models.CharField(max_length=30)
    se_num=models.CharField(max_length=34)
    result=models.TextField(default=None)

    