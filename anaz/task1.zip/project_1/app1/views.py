from django.http import HttpResponse
from django.shortcuts import render
from . models import *

# Create your views here.
def home(request):
    if request.method == 'POST':
        first_num=request.POST['f_num']
        second_num=request.POST['s_num']
        resu=request.POST['res']
        res=first_num + second_num
        add=Reg(fi_num=first_num,se_num=second_num,result=resu)
        add.save()
        Reg.objects.filter(fi_num='ana@gmail.com').update(se_num='yyyyyy')
    else:
        return render(request,'test.html',{'resl':res})
    
    return render(request,'home.html',{'resl':res})    
def tst(request):
    if request.method == 'POST':
        resu=request.POST['res']
    return render(request,'test.html',{'resl':resu})


