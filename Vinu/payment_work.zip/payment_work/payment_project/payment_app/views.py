from django.shortcuts import render
from django.http import HttpResponseRedirect

def transaction_view(request):
    success_message = None

    if request.method == "POST":
        amount = request.POST.get('amount')
        payment_method = request.POST.get('payment_method')

    
        if amount and payment_method:
            success_message = f"Rs {amount} payment {payment_method} was successfully completed!"

    return render(request, 'payment.html', {'success_message': success_message})
