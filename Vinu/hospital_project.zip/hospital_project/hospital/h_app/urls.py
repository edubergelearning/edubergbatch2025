from django.urls import path
from .views import home, patients, add_patient, update_patient, delete_patient, book

urlpatterns = [
    path('', home, name='home'),
    path('patients/',patients, name='patients'),
    path('add_patient/',add_patient, name='add_patient'),
    path('update_patient/<int:pk>/',update_patient, name='update_patient'),
    path('delete_patient/<int:pk>/',delete_patient, name='delete_patient'),
    path('book/',book, name='book'),
]
