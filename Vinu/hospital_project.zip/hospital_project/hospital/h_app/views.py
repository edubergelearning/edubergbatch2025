from django.shortcuts import render, redirect, get_object_or_404
from .models import Patient

def home(request):
    return render(request, 'home.html')

def patients(request):
    patients = Patient.objects.all()
    return render(request, 'patients.html', {'patients': patients})

def add_patient(request):
    if request.method == "POST":
        name = request.POST['name']
        email = request.POST['email']
        disease = request.POST['disease']
        Patient.objects.create(name=name, email=email, disease=disease)
        return redirect('patients')
    return redirect('patients')

def update_patient(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    if request.method == "POST":
        patient.name = request.POST['name']
        patient.email = request.POST['email']
        patient.disease = request.POST['disease']
        patient.save()
        return redirect('patients')
    return redirect('patients')

def delete_patient(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    patient.delete()
    return redirect('patients')

def book(request):
    patients = Patient.objects.all()
    return render(request, 'book.html', {'patients': patients})
