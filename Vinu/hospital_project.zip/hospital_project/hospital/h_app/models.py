from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=100)
    email = models.EmailField()
    disease = models.CharField(max_length=100)
    admitted_date = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name

