from django.shortcuts import render

def multiply_view(request):
    result = None

    if request.method == "POST":
        num1 = request.POST.get("num1")
        num2 = request.POST.get("num2")

        if num1 and num2:
            try:
                result = int(num1) * int(num2)
            except ValueError:
                result = "Invalid input! Please enter numbers only."

    return render(request, "mathapp/multiply.html", {"result": result})
